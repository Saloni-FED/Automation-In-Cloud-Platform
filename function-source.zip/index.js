const functions = require('@google-cloud/functions-framework');
const https = require('https');

functions.http('helloHttp', (req, res) => {
  console.log("Request headers:", req.headers);
  console.log("Request body:", req.body);

  // Extract the event type and other relevant CloudEvent headers
  const eventType = req.headers['ce-type'];
  console.log(eventType)

  
  // Prepare the data to send, including both the original request body and the CloudEvent metadata
  const postData = JSON.stringify({
    eventType: eventType,
    eventData: req.body
  });

  // Options for the HTTPS request
  const options = {
    hostname: 'insect-uncommon-luckily.ngrok-free.app',
    path: '/webhook-eventarc',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData),
      'CE-Type': eventType,
    }
  };

  // Make the HTTPS request
  const request = https.request(options, (response) => {
    let data = '';

    response.on('data', (chunk) => {
      data += chunk;
    });

    response.on('end', () => {
      console.log('Webhook response:', data);
      res.send(`Processed ${eventType} event`);
    });
  });

  request.on('error', (error) => {
    console.error('Error forwarding to webhook:', error);
    res.status(500).send('Error forwarding request to webhook');
  });

  // Write data to request body
  request.write(postData);
  request.end();
});
